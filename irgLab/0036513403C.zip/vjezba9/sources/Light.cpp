#include "Light.h"

void Light::print() {
	std::cout << ir << " " << ig << " " << ib << std::endl;
}